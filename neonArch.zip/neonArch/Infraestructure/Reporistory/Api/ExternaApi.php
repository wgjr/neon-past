<?php

class ExternaApi
{

}