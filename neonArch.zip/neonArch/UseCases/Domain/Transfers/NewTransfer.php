<?php

namespace Transfers;

class NewTransfer extends Transfer
{

}