<?php

namespace Transfers;
class Transfer
{
   private function validate(){

   }

   private function accountEx(){

   }

   private function saveTemp(){

   }

   private function apiNeon(){
       return false;
   }

   private function apiExterna(){
       return false;
   }

   private function run(){

   }
}