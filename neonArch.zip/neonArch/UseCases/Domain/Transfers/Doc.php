<?php

namespace Transfers;

class Doc
{
    private function validate(){

    }

    public function run(){

    }
}