<?php

class AccountObject
{
    public function __construct()
    {
        $contAccountLet = '';
    }
}