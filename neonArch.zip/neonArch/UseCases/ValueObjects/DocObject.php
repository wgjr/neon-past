<?php

class DocObject
{

}