<?php

class TransferObject
{

}